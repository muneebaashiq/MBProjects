plugins {
    id("java")
}

group = "org.example"
version = "1.0-SNAPSHOT"

repositories {
    mavenCentral()
}

dependencies {
    testImplementation(platform("org.junit:junit-bom:5.9.1"))
    testImplementation("org.junit.jupiter:junit-jupiter")


    testImplementation("com.thoughtworks.xstream:xstream:1.4.18")
    testImplementation("org.elasticsearch:elasticsearch:7.9.1")
    testImplementation("com.liferay.portal:release.portal.bom:7.3.6")
    testImplementation("io.undertow:undertow-core:2.2.6.Final")
    testImplementation("org.apache.tomcat.embed:tomcat-embed-core:9.0.78")
    testImplementation("org.keycloak:keycloak-parent:12.0.2")
    testImplementation("org.springframework:spring-core:5.3.10")
    testImplementation("org.apache.nifi:nifi:1.14.0")
    testImplementation("org.eclipse.jetty:jetty-server:9.4.43.v20210629")
    testImplementation("org.apache.solr:solr-core:8.11.1")
    testImplementation("org.springframework.security:spring-security-core:5.5.3")
    testImplementation("org.keycloak:keycloak-services:12.0.2")
    testImplementation("org.apache.geode:geode-core:1.15.0")
    testImplementation("org.bouncycastle:bcprov-jdk14:1.70")
    testImplementation("org.apache.activemq:activemq-client:5.16.0")
    testImplementation("org.apache.dubbo:dubbo:2.7.10")
    testImplementation("org.apache.jspwiki:jspwiki-main:2.11.0.M8")
    testImplementation("org.apache.cxf:cxf:3.4.7")
    testImplementation("org.apache.hadoop:hadoop-main:3.3.1")
    testImplementation("org.apache.hadoop:hadoop-common:3.3.1")
    testImplementation("org.apache.jspwiki:jspwiki-war:2.11.0.M8")
    testImplementation("org.apache.ranger:ranger:2.0.0")
    testImplementation("com.vaadin:flow-server:6.0.6")
    testImplementation("com.vaadin:vaadin-bom:22.0.6")
    testImplementation("org.apache.camel:camel-core:3.14.0")
    testImplementation("org.apache.cxf:cxf-core:3.4.7")
    testImplementation("org.apache.inlong:manager-service:0.3.0")
    testImplementation("org.jboss.netty:netty:3.2.0.Final")
    testImplementation("org.jenkins-ci.plugins.workflow:workflow-cps:2.12")
    testImplementation("org.jenkins-ci.plugins.workflow:workflow-cps-global-lib:2.6")
    testImplementation("com.sonyericsson.jenkins.plugins.bfa:build-failure-analyzer:1.28")
    testImplementation("org.jenkins-ci.plugins:git:3.0.1")
    testImplementation("org.bouncycastle:bcprov-jdk15:1.54")
    testImplementation("org.apache.struts.xwork:xwork-core:2.3.28")
    testImplementation("org.xwiki.platform:xwiki-platform-web:12.10.10")
    testImplementation("org.xwiki.platform:xwiki-platform-web-templates:12.10.10")
    testImplementation("org.apache.openmeetings:openmeetings-parent:2.0.0")
    testImplementation("org.jenkins-ci.plugins:script-security:1.1")
    testImplementation("com.jfinal:jfinal:5.0.0")
    testImplementation("net.mingsoft:ms-mcms:5.2.8")
    testImplementation("com.fasterxml.jackson.core:jackson-databind:2.13.0")
    testImplementation("org.apache.struts:struts2-core:6.0.0")
    testImplementation("org.keycloak:keycloak-core:23.0.4")
    testImplementation("org.xwiki.platform:xwiki-platform-oldcore:15.1")
    testImplementation("org.apache.inlong:manager-pojo:1.9.0")
    testImplementation("org.apache.tika:tika-core:1.28.2")
    testImplementation("org.jeecgframework.boot:jeecg-boot-parent:2.3.9")
    testImplementation("io.netty:netty:3.9.1.Final")
}

tasks.test {
    useJUnitPlatform()
}